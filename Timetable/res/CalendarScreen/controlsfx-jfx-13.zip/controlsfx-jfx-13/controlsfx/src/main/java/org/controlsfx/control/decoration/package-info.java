/**
 * A package containing decoration-related API (that is, API to allow for users
 * to 'decorate' nodes with additional nodes or css decorations.
 */
package org.controlsfx.control.decoration;